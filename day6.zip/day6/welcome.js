document.writeln("<h1>Welcome To JavaScript @ VibrantMindsTech</h1>");

console.log("Welcome To JavaScript");