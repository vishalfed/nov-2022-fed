//display the message
document.writeln("<h1>Welcome To Java Script</h1>") 
document.writeln("<h1>Welcome To Java Script</h1>") 
document.writeln("<h1>Welcome To Java Script</h1>")
