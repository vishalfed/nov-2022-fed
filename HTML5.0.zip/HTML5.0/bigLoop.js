for (var i = 0; i <= 1000000000; i += 1){
var j = i;
}

postMessage(j);