package com.cts.jquery;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

/**
 * Servlet implementation class ViewCities
 */
public class ViewCities extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HashMap<String, List<String>> map;
	   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewCities() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		map=new HashMap<String,List<String>>();
		map.put("MH", Arrays.asList("PUNE","MUMBAI","NAGPUR"));
		map.put("KN", Arrays.asList("BANGLORE","HUBLI","BELGAON"));
		map.put("AP", Arrays.asList("VAIZAG","VIJAYWADA","HYDERABAD"));
		System.out.println(map);
		
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		map.clear();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*response.setContentType("text/xml");
		PrintWriter pw=response.getWriter();	
		
		String state=request.getParameter("state");
		
		if(state!=null){
		System.out.println("In doGet...");	
		List<String> cities=map.get(state);	
		System.out.println(cities);
		pw.println("<?xml version='1.0' ?>");
		pw.println("<cities>");
		for(String s:cities)
		pw.println("<city>"+s+"</city>");
		pw.println("</cities>");
		}
	*/

		
	
		
		
		
		PrintWriter pw=response.getWriter();	
		String state=request.getParameter("state");
		if(state!=null){
			System.out.println("In doGet...");	
			List<String> cities=map.get(state);	
			System.out.println(cities);
		    JSONObject object=new JSONObject();
		    object.put("cities",cities);
			
			pw.println(object);
		
		}	
	
	
	
	}

}
