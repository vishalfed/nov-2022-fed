<?php
 
$post_name=$_REQUEST["name"];
 
$post_location=$_REQUEST["location"];
 
if( $post_name )
 
{
 
   echo "Name entered is: ". $post_name ."<br>";
 
   echo "Location:" .$post_location;
 
}
 
?>  